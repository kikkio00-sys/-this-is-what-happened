
const nav = document.getElementById('museumNav');
const menuButton = document.getElementById('menuButton');
const homeButton = document.getElementById('homeButton');
const rooms = [...document.querySelectorAll('.room')];
const links = [...document.querySelectorAll('.nav-link')];

function showRoom(id){
  rooms.forEach(room => room.classList.toggle('active-room', room.id === id));
  links.forEach(link => link.classList.toggle('active', link.dataset.room === id));
  nav.classList.remove('open');
  window.scrollTo({top:0, behavior:'smooth'});
}

links.forEach(link => link.addEventListener('click', () => showRoom(link.dataset.room)));
document.querySelectorAll('[data-go]').forEach(button => {
  button.addEventListener('click', () => showRoom(button.dataset.go));
});
menuButton.addEventListener('click', () => nav.classList.toggle('open'));
homeButton.addEventListener('click', () => showRoom('entrance'));

document.addEventListener('keydown', event => {
  if(event.key === 'Escape') nav.classList.remove('open');
});


const familyExhibits = document.getElementById('familyExhibits');
const exhibitContent = document.getElementById('exhibitContent');

function renderFamily(){
  if(!familyExhibits || !window.MUSEUM_FAMILY) return;
  familyExhibits.innerHTML = window.MUSEUM_FAMILY.map(person => `
    <article class="person-card exhibit-card" data-person="${person.id}">
      <div class="portrait-placeholder">${person.portrait ? `<img src="${person.portrait}" alt="">` : person.name.replace(" Room","").replace("Your ","")}</div>
      <p class="eyebrow dark">${person.relationship}</p>
      <h3>${person.name}</h3>
      <p>${person.summary}</p>
      <button class="primary-button open-exhibit" data-person="${person.id}">Enter Exhibit</button>
    </article>
  `).join('');
  document.querySelectorAll('.open-exhibit').forEach(btn => btn.addEventListener('click', () => openExhibit(btn.dataset.person)));
}

function openExhibit(id){
  const person = window.MUSEUM_FAMILY.find(p => p.id === id);
  if(!person) return;
  exhibitContent.innerHTML = `
    <p class="eyebrow dark">${person.relationship}</p>
    <h2>${person.name}</h2>
    <p class="lead">${person.summary}</p>
    <div class="exhibit-portrait">${person.portrait ? `<img src="${person.portrait}" alt="">` : 'Portrait installation point'}</div>
    <div class="exhibit-columns">
      <div>
        ${person.chapters.map(ch => `<div class="chapter"><h3>${ch.title}</h3><p>${ch.text}</p></div>`).join('')}
      </div>
      <aside>
        <h3>Timeline</h3>
        <ul>${person.timeline.map(item => `<li>${item}</li>`).join('')}</ul>
        <h3>Artifact Cases</h3>
        <ul>${person.artifacts.map(item => `<li>${item}</li>`).join('')}</ul>
      </aside>
    </div>`;
  showRoom('exhibit');
}
document.getElementById('backToFamily')?.addEventListener('click', () => showRoom('family'));
renderFamily();

const searchOverlay = document.getElementById('searchOverlay');
const searchButton = document.getElementById('searchButton');
const closeSearch = document.getElementById('closeSearch');
const museumSearch = document.getElementById('museumSearch');
const searchResults = document.getElementById('searchResults');

const searchableRooms = [...document.querySelectorAll('.room')].filter(r => r.id !== 'exhibit').map(r => ({
  id:r.id,
  title:r.querySelector('h2')?.textContent || r.id,
  text:r.textContent.replace(/\s+/g,' ').trim()
}));

function runSearch(value){
  const q = value.trim().toLowerCase();
  if(!q){ searchResults.innerHTML = '<p>Type a name, room, story, or artifact.</p>'; return; }
  const roomMatches = searchableRooms.filter(item => item.text.toLowerCase().includes(q));
  const peopleMatches = (window.MUSEUM_FAMILY || []).filter(p =>
    JSON.stringify(p).toLowerCase().includes(q)
  );
  const results = [
    ...peopleMatches.map(p => `<button class="search-result" data-person="${p.id}"><strong>${p.name}</strong><span>${p.relationship}</span></button>`),
    ...roomMatches.map(r => `<button class="search-result" data-room="${r.id}"><strong>${r.title}</strong><span>Museum room</span></button>`)
  ];
  searchResults.innerHTML = results.length ? results.join('') : '<p>No museum exhibits matched that search.</p>';
  document.querySelectorAll('.search-result[data-room]').forEach(b => b.addEventListener('click', () => { closeSearchPanel(); showRoom(b.dataset.room); }));
  document.querySelectorAll('.search-result[data-person]').forEach(b => b.addEventListener('click', () => { closeSearchPanel(); openExhibit(b.dataset.person); }));
}
function openSearchPanel(){
  searchOverlay.classList.add('open');
  searchOverlay.setAttribute('aria-hidden','false');
  museumSearch.focus();
  runSearch('');
}
function closeSearchPanel(){
  searchOverlay.classList.remove('open');
  searchOverlay.setAttribute('aria-hidden','true');
}
searchButton?.addEventListener('click', openSearchPanel);
closeSearch?.addEventListener('click', closeSearchPanel);
searchOverlay?.addEventListener('click', e => { if(e.target === searchOverlay) closeSearchPanel(); });
museumSearch?.addEventListener('input', e => runSearch(e.target.value));

if('serviceWorker' in navigator){
  window.addEventListener('load', () => navigator.serviceWorker.register('service-worker.js').catch(() => {}));
}
