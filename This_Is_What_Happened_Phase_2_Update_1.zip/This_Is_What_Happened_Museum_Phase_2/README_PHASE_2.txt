THIS IS WHAT HAPPENED — PHASE 2, UPDATE 1

WHAT WAS ADDED
- Home-screen app icon and manifest
- Offline caching after the first visit
- Museum-wide search
- Dynamic immediate-family exhibit cards
- Full individual exhibit template
- Separate family-data.js file for replacing placeholders with real names and stories
- Portrait installation points
- Timeline, artifact, and biography sections for each person

HOW TO UPDATE CLOUDFLARE
1. Extract this ZIP in iCloud Drive.
2. In Cloudflare, open this-is-what-happened.
3. Choose Deployments / upload a new version.
4. Select the entire extracted folder.
5. Deploy.

IMPORTANT
This starts Phase 2 without inventing private family facts. The current three exhibits are structured placeholders. Replace them after names, photos, and stories are supplied.
