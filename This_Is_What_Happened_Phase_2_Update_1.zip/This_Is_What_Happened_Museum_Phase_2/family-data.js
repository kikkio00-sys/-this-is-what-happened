window.MUSEUM_FAMILY = [
  {
    id: "you",
    name: "Your Museum Room",
    relationship: "Museum Curator",
    portrait: "",
    summary: "Your life story, timeline, memories, places, photographs, documents, historical context, and narration.",
    chapters: [
      { title: "Early Life", text: "This chapter is ready for your childhood, family surroundings, schools, places, and early memories." },
      { title: "Becoming", text: "This chapter is ready for work, relationships, turning points, hardships, joys, and accomplishments." },
      { title: "Legacy", text: "This chapter is ready for the values, traditions, lessons, and memories you want future generations to inherit." }
    ],
    timeline: ["Birth and childhood", "Important turning points", "Family milestones", "Legacy memories"],
    artifacts: ["Portraits", "Letters", "Documents", "Voice recordings"]
  },
  {
    id: "husband",
    name: "Your Husband's Room",
    relationship: "Living Family",
    portrait: "",
    summary: "His life story, timeline, memories, places, photographs, documents, historical context, and narration.",
    chapters: [
      { title: "Early Life", text: "Ready for childhood, family surroundings, schools, places, and early memories." },
      { title: "Becoming", text: "Ready for work, relationships, turning points, hardships, joys, and accomplishments." },
      { title: "Legacy", text: "Ready for the values, traditions, lessons, and memories he wants future generations to inherit." }
    ],
    timeline: ["Birth and childhood", "Important turning points", "Family milestones", "Legacy memories"],
    artifacts: ["Portraits", "Letters", "Documents", "Voice recordings"]
  },
  {
    id: "children",
    name: "Your Children's Rooms",
    relationship: "Next Generation",
    portrait: "",
    summary: "Living exhibits for milestones, photographs, traditions, stories, and letters to the future.",
    chapters: [
      { title: "Early Years", text: "Ready for childhood memories, favorite places, family traditions, and milestones." },
      { title: "Growing Story", text: "Designed to expand as each life continues." },
      { title: "Letters to the Future", text: "A place for advice, hopes, family stories, and messages for later generations." }
    ],
    timeline: ["Birth and childhood", "Milestones", "Family traditions", "Future chapters"],
    artifacts: ["Photographs", "Artwork", "Letters", "Recordings"]
  }
];
